package appointment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AppointmentUpdateProcess")
public class AppointmentUpdateProcess extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AppointmentUpdateProcess() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String aID = request.getParameter("aID");
        String PatientName = request.getParameter("PatientName");
        String AppCon = request.getParameter("AppCon");
        String AppNic = request.getParameter("AppNic");
        String AppAddress = request.getParameter("AppAddress");
        String Doctor = request.getParameter("Doctor");
        String AppDate = request.getParameter("AppDate");
        String AppTime = request.getParameter("AppTime");
        String pay = request.getParameter("pay");
        String amount = request.getParameter("amount");
       

        if (aID != null) {
            Connection con = null;
            PreparedStatement ps = null;
            int personID = Integer.parseInt(aID);
            try {
                String driverName = "com.mysql.jdbc.Driver";
                String url = "jdbc:mysql://localhost:3306/labappoint";
                String user = "root";
                String psw = "";

                Class.forName(driverName);
                con = DriverManager.getConnection(url, user, psw);
                String sql = "UPDATE appoint SET PatientName=?, AppCon=?, AppNic=?, AppAddress=?, Doctor=?, AppDate=?, AppTime=?, pay=?, amount=? WHERE aID = ?";
                ps = con.prepareStatement(sql);
                ps.setString(1, PatientName);
                ps.setString(2, AppCon);
                ps.setString(3, AppNic);
                ps.setString(4, AppAddress);
                ps.setString(5, Doctor);
                ps.setString(6, AppDate);
                ps.setString(7, AppTime);
                ps.setString(8, pay);
                ps.setString(9, amount);;
                ps.setInt(10, personID);

                int i = ps.executeUpdate();
                if (i > 0) {
                	
                    RequestDispatcher rd = request.getRequestDispatcher("AppointmentManage.jsp");
                    rd.forward(request, response);
                } else {
                    response.getWriter().write("There is a problem in updating Record.");
                }
            } catch (SQLException e) {
                request.setAttribute("error", e);
                response.getWriter().write(e.toString());
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (ps != null) {
                        ps.close();
                    }
                    if (con != null) {
                        con.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
