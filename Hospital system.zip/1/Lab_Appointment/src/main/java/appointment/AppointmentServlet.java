package appointment;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//Import Database Connection Class file 


@WebServlet("/AppointmentServlet") 
public class AppointmentServlet extends HttpServlet{
	
	private static final long serialVersionUID = 1L; 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{ 
	
		String PatientName = request.getParameter("PatientName");		
		String AppCon = request.getParameter("AppCon");
		String AppNic = request.getParameter("AppNic");	
		String AppAddress = request.getParameter("AppAddress");
		String Doctor = request.getParameter("Doctor");		
		String AppDate = request.getParameter("AppDate");	
		String AppTime = request.getParameter("AppTime");
		String pay = request.getParameter("pay");
		String amount = request.getParameter("amount");		

		
		 Connection conn = null;
		    
		    try {
		    	String sql = "insert into appoint(PatientName,AppCon,AppNic,AppAddress,Doctor,AppDate,AppTime,pay,amount) values(?,?,?,?,?,?,?,?,?)";
		    	Class.forName("com.mysql.cj.jdbc.Driver");
			     conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/labappoint","root","");
			    PreparedStatement st = conn.prepareStatement(sql);
			   

			    st.setString(1, PatientName);
			    st.setString(2, AppCon);			    
			    st.setString(3, AppNic);			    
			    st.setString(4, AppAddress);
			    st.setString(5, Doctor);			    
			    st.setString(6, AppDate);			    
			    st.setString(7, AppTime);	
			    st.setString(8, pay);
			    st.setString(9, amount);
	

			     int row = st.executeUpdate();
			     
			    System.out.println("db connected!!");

		        if (row > 0) {
		          System.out.println("File uploaded and saved into database");
		          
		         
		          

		          
		          RequestDispatcher rd = request.getRequestDispatcher("/Index.jsp");
		          
		          rd.include(request, response);
		        }
		       
		    }catch (Exception e) {
				e.printStackTrace();

      } 		
	} 	
} 



